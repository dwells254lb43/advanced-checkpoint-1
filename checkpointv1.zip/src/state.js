export default {
  searchResults: [],
  myMovieList: []
};
