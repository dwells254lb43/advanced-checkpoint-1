
export function loadMyMovieList(){
  return function (dispatch) {
    dispatch({
      type: "LOAD_MY_MOVIE_LIST"
    });
    fetch("/movies")
    .then( (response) => {
       return response.json();
        }).then((movies) => {
      dispatch(myMovieListLoaded(movies));
    });
  };
}

export function myMovieListLoaded(movies){
  return{
    type: "MY_MOVIE_LIST_LOADED",
    value: movies
  };
}

export function loadSearch(searchTerm){
  return function (dispatch) {
    dispatch({
      type: "LOAD_SEARCH"
    });
    fetch("https://api.themoviedb.org/3/search/multi?include_adult=false&page=1&query=" + searchTerm + "&language=en-US&api_key=695c9f4e37dddc0d2454972d0fa279a9")
    .then( (response) => {
       return response.json();
     }).then((movies) => {
      dispatch(checkTrailer(movies));
    });
  };
}

export function checkTrailer(movies) {
  let newMovies = movies.results.map( (m) => {
      let tempMovie = m;
    if (m.media_type == "movie") {
      fetch("https://api.themoviedb.org/3/movie/" + m.id +"/videos?language=en-US&api_key=695c9f4e37dddc0d2454972d0fa279a9")
      .then( (response) => {
        return response.json();
      }).then((key) => {
        if(key.results[0].key != undefined)
        tempMovie.trailer = key.results[0].key;
        else {
          tempMovie.trailer = "no-trailer";
        }
      });
    } else {
      tempMovie = m;
      tempMovie.trailer = "no-trailer";
    }
    return tempMovie;
  });


  return function (dispatch) {
    dispatch({type: "CHECK_TRAILER"});
    (dispatch(searchLoaded(newMovies)));
  }
}


export function searchLoaded(movies){
  return{
    type: "SEARCH_RESULTS_LOADED",
    value: movies
  };
}

export function saveMyMovie(movie) {
 return function (dispatch) {
   fetch("/movies", {
     method: "POST",
     headers: {"Content-Type": "application/json"},
     body: JSON.stringify(movie)
   }).then(() => dispatch(loadMyMovieList()));
 };
}

export function removeMyMovie(id) {
 return function (dispatch) {
   fetch("/movies/" + id, {
     method: "DELETE",
   }).then(() => dispatch(loadMyMovieList()));
 };
}
