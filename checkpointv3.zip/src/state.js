export default {
  searchResults: [],
  myMovieList: [],
  popularMovies: []
};
